<?php
require_once __DIR__.'/includes/config.php';
            es\ucm\fdi\aw\Mazmorras::cargaMazmorraInicial(11);
//            es\ucm\fdi\aw\Mazmorras::mazmorraDirNorte();
//            es\ucm\fdi\aw\Mazmorras::mazmorraDirSur();
//            es\ucm\fdi\aw\Mazmorras::mazmorraDirEste();
//            es\ucm\fdi\aw\Mazmorras::mazmorraDirOeste();

?>
