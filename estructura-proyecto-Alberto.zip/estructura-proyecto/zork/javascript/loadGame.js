var panel = $('#zork-area');

var inventario = [];
var rooms = {};



$(document).on('click', '#start', function(e) {
    
    var p = $('#subwrapper').prepend('<h2>Comenzamos! (teclea ayuda para mas info)</h2>');
    $(function(){ 

          $.ajax({ 

            method: "GET", 
            
            url: "loadMapa.php",
            data: JSON.stringify(e),
            success: function( data ) { 
               
                var result= $.parseJSON(data); 
                 panel.append('<br><button id="getvalue">Siguiente</button>') 

                //var string= [];
                var myArrayMap = [];
               

                //console.log (result.length)
                if(result.length !== 0){
                   /* from result create a string of data and append to the div */
                    $.each( result, function( key, value ) { 
                      
                      //string[i] = value['idMap'] + value['idRoom'] + value['inventario']; 
                      myArrayMap.push(value);
    
                          }); 
                      //console.log(myArrayMap[0]); 
                      //console.log(myArrayMap.length); 

                      //for(i=0; i<string.length; i++) alert(i + ': ' + string[i]); 
                    panel.empty()
                    choiceMap(myArrayMap);
                    //load();
                }
                else{
                    //panel.empty()
                    alert("Error al cargar la base de datos")
                    p.empty()
                
                }
            }

          }); 
         
    }); 

    

})

function choiceMap (myArray){

    
    panel.append("Selecciona el mapa que quieras jugar")
    panel.append("<form name=fmap>")
    for(i=0; i<myArray.length; i++){
        
        panel.append('<legend><input type="Radio" name="mapas" value="'+ myArray[i].id +'">Mapa: '+i+"</legend><p>Nombre:   "+ myArray[i].nombre+"</p> "+"<p>Dificultad:   "+myArray[i].dificultad +"</p>")
    }
    panel.append('<p></p><button id="getvalue">Siguiente</button>') 
    panel.append("</form>")

    jQuery('#getvalue').on('click', function(e) {  
        selValue = document.querySelector('input[name = "mapas"]:checked').value;
        mapa = myArray[selValue]
        
        //inventario = mapa.inventario.split(",")
        
        panel.empty()
        sqlRooms(selValue)
    });
}

function sqlRooms(selValueMap){ 
    $(document).ready(function() {
        
         $.ajax({ 

            method: "GET", 
            
            url: "loadMazmorras.php",

            success: function(msg){
                var result= $.parseJSON(msg); 

                //var arstring= [];
                var myArray = [];
                
                if(result.length !== 0){
                   /* from result create a string of data and append to the div */
                    $.each( result, function( key, value ) {
 
                            myArray.push(value);  
                    }); 
					var monstruos=[];
					var consumibles=[];
					var numSalidas;
					
					var mazmorraIni= new Mazmorra(monstruos,consumibles,myArray[0].historia,myArray[0].numSalidas,myArray[0].recompensa,myArray[0].direccionNorte,myArray[0].direccionSur,myArray[0].direccionEste,myArray[0].direccionOeste,myArray[0].ultima);
                    console.log(myArray);
					mazmorraIni.inicializa();
                    console.log(myArray.length); 
                    //console.log("tipo dato " + typeof rooms)

                    loadRoom(myArray);
                }
                else{
                    //panel.empty()
                    alert("Error al cargar la base de datos")
                    p.empty()
                
                }
            }
        });
    
    });
}

function loadRoom(myArray){
    //console.log(rooms)
    
    for(i=0; i < myArray.length; i++){
        rooms[myArray[i].nameRoom] = {};
        rooms[myArray[i].nameRoom].description = myArray[i].description;
        rooms[myArray[i].nameRoom].directions = {}

        direccion = myArray[i].direccion.split(",")
        destino = myArray[i].destino.split(",")

        for(j=0; j < direccion.length; j++){
            rooms[myArray[i].nameRoom].directions[direccion[j]] = destino[j]
        }
        rooms[myArray[i].nameRoom].image = myArray[i].imagen
        rooms[myArray[i].nameRoom].pickUp = []
        rooms[myArray[i].nameRoom].pickUp.push(myArray[i].pickUp)


    }
    console.log(rooms)
    startGame()
	Mazmorra();

}
//ALBERTO JS
//--------------------------------------------------------clase mazmorra----------------------------------------------------------
var Mazmorra= function(monstruos, consumibles,historia,numSalidas,recompensa,dirNorte,dirSur,dirEste,dirOeste,ultima){
	var listaConsumibles;
	var listaMonstruos;
	var listaRespuestas;
	var historiaPrincipal;
	var numSalidas;
	var recompensa;
	//Las dirreciones pasadas al objeto mazmorra son objetos de tipo Direccion
	var mazmorraNorte;
	var mazmorraSur;
	var mazMorraEste;
	var mazMorraOeste;
	//argumento para saber si es la ultima mazmorra para poder terminar el juego de forma exitosa.
	var ultima;
	
	this.inicializa= function(){
		this.carga();
		this.numSalidas=numSalidas;
		this.mazMorraOeste=dirOeste.getMazmorra();
		this.mazmorraEste=dirEste.getMazmorra();
		this.mazmorraNorte=dirNorte.getMazmorra();
		this.mazmorraSur=dirSur.getMazmorra();
		this.historiaPrincipal=historia;

	}
	//se debe contemplar el numero de salidas, que sera como maximo 4, pero debemos identificar cada salida con un indice fijo
	//Por ejemplo 4 direcciones distintas , que se pasaran por parametro
	this.carga=function(){
		this.cargaMonstruos(monstruos);
		this.cargaConsumibles(consumibles);
		this.cargarRespuestasMazmorra();

	}
	this.cargaMonstruos= function(monstruos){
		for (var i = 0; i < monstruos.length; i++) {
			this.listaMonstruos.push(monstruos[i]);
			this.listaRespuestas.push(monstruos[i].getListaRespuestas());
		}

	}
	this.cargaConsumibles= function(consumibles){
		for (var j = 0; j < monstruos.length; j++) {
			this.cargaConsumibles.push(consumibles[j]);
			this.listaRespuestas.push(consumibles[j].getListaRespuestas());
		}

	}	
	this.cargarRespuestasMazmorra=function(){
		if(dirOeste.getMazmorra()!=null){
			this.listaRespuestas.push(dirOeste.getMensaje());
		}
		if(dirEste.getMazmorra()!=null){
			this.listaRespuestas.push(dirEste.getMensaje());
		}
		if(dirNorte.getMazmorra()!=null){
			this.listaRespuestas.push(dirNorte.getMensaje());
		}
		if(dirSur.getMazmorra()!=null){
			this.listaRespuestas.push(dirSur.getMensaje());
		}
	}
	this.getHistoriaPrincipal=function(){
		return this.historiaPrincipal;

	}
	this.getListaMonstruos=function(){
		return this.listaMonstruos;
	}
	this.getListaConsumibles= function(){
		return this.listaConsumibles;

	}
	this.getListaRespuestas = function(){
		return this.listaRespuestas;

	}
	this.setHistoriaPrincipal = function(historia){
		this.historiaPrincipal=historia;
	}
	this.getRecompensa= function(){
		return this.recompensa;
	}
	//devuelve si es la mazmorra de salida.
	this.esFin= function(){
		return this.ultima;
	}


};
//ALBERTO JS
//--------------------------------------------------------clase Direccion----------------------------------------------------------
var Direccion =function(direccion,mazmorra){
	var mazmorra;
	var mensaje;
	this.inicializa=function(){
		this.mazmorra=mazmorra;
		this.mensaje=mensaje;
	}
	//Aqui se mostrara el mensaje correspondiente a la direccion, por ejemplo: Ir por la puerta al Norte. o  la Puerta 0;
	this.getMensaje=function(){
		return this.mensaje;

	}
	//aqui se devolvera la mazmorra asociada a esa direccion.
	this.getMazmorra=function(){
		return this.mazmorra;

	}
};
//ALBERTO JS
//--------------------------------------------------------clase Consumible----------------------------------------------------------
var Consumible= function(id,categoria,nombre,fuerza,habilidad,vida,imagenConsumible,respuestas){
	//cada consumible tendra una respuesta asociada por lo que en la base de datos debe estar pasada como parametro para cada consumible.
	//por ejemplo todos los onjetos consumibles se podran coger para añadirse al inventario.

	var categoria;
	var nombre;
	var fuerza;
	var habilidad;
	var vida;
	var imagen;
	var id;
	var listaRespuestas;

	this.inicializa= function(){
		this.categoria=categoria;
		this.nombre=nombre;
		this.fuerza=fuerza;
		this.habilidad=habilidad;
		this.vida=vida;
		this.imagen=imagenConsumible;
		this.listaRespuestas=respuestas;

	}
	//por defecto los efetos que no esten contemplados segun la categoria valdran 0 y no NULL.
	this.getFuerza=function(){
		return this.fuerza;
	}
	this.getNombre=function(){
		return this.nombre;
	}
	this.getCategoria=function(){

		return this.categoria;

	}
	this.getHabilidad=function(){

		return this.habilidad;

	}
	this.getVida=function(){
		return this.vida;
	}
	this.getId=function(){
		return this.id;
	}
	this.getListaRespuestas=function(){

		return this.listaRespuestas;
	}


};

//ALBERTO JS
//--------------------------------------------------------clase Monstruo----------------------------------------------------------
var Monstruo= function(vida, ataque,imagenMonstruo,respuestas){
	//en la base de datos los monstruos tendran unas respuestas asociadas fijas, ya que a un monstruo solo se le puede atacar o huir de el.

var vida;
var ataque;
var imagenMonstruo;
var listaRespuestas;
this.inicializa=function(){
	this.vida=vida;
	this.ataque=ataque;
	this.imagenMonstruo=imagenMonstruo;
	this.listaRespuestas=respuestas;
}

this.perderVida=function(daño){
	this.vida-=daño;
}
this.getAtaque =function(){
	return this.ataque;
}
this.getListaRespuestas= function(){

	return this.listaRespuestas;
}

};
//ALBERTO JS
//--------------------------------------------------------clase Personaje----------------------------------------------------------
var Personaje= function(vida,nombre,fuerza,inventario,imagen){

	var vidaAct;
	var vidaMax;
	var inventario;
	var imagen;
	var fuerza;
	var nombre;
	var fuerza;
	var mazMorraActual;

	this.inicializa=function(){
		this.vidaMax=vida;
		this.vidaAct=vida;
		this.nombre=nombre;
		this.fuerza=fuerza;
		this.imagen=imagen;
		this.cargaInv(inventario);
	}
	this.cargaInv=function(inventario){
		for (var i = 0; i < inventario.length; i++) {
			this.inventario.push(inventario[i]);
		}
	}

	this.restavida=function(daño){
		this.vidaAct-=daño;
	}

	this.getVida=function(){
		return this.vida;
	}
	this.sumVidaMax= function(vida){
		this.vidaMax+=vida;
	}
	this.sumFuerza= function(fuerzaObjeto){
		this.fuerza+=fuerzaObjeto;
	}
	this.insertaInventario=function(consumible){
		this.inventario.push(consumible.getId());
	}
	//Suma todos los campos del consumible para actualizar el estado del jugador en nivel de caracteristicas
	this.interactuarConsumible=function(consumible){
		if(consumible.getCategoria()!="pocion"){
			if(this.vidaAct < vidaMax )
				this.vidaAct+=consumible.getVida();
		}
		else{
			this.fuerza+=consumible.getVida();
			this.habilidad+=consumible.getHabilidad();
			this.vidaMax+=consumible.getVida();
		}
		eliminaInventario(consumible.getId());
	}
	this.eliminaInventario=function(idConsum){
		for (var j = 0; j < this.inventario.length; j++) {
			if(this.inventario[j]==idConsum){
				this.inventario.splice(j,1);
			}
		}
	}
	this.getFuerza=function(){
		return this.fuerza();

	}

};


