<?php
require_once __DIR__.'/includes/config.php';
            $mapa = es\ucm\fdi\aw\Mapa::cargaMapas();
?>
