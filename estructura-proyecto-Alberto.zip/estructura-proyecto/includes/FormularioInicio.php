<div id="formulario">
	<form action='procesarLogin.php' method="POST"> 
	<h3>Registrate ¡Gratis!</h3>

	<label>Nombre de usuario: </label>
    <p><input type="text" name="user"/></p>
    <label>Email: </label>
    <p><input type="email" name="email"/></p>
    <label>Contraseña: </label>
    <p><input type="password" name="password"/></p>
    <label>Repetir contraseña: </label>
    <p><input type="password" name="password2"/></p>
    <input type="submit" value="Registrarse"/>
	
	</form>
</div>