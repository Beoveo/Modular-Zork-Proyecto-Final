<div id="pie">
	<a href='contacto.php'class='button' >Contacto</a>
    <a href='desarrolladores.php'class='button' >Desarrolladores</a>
</div>