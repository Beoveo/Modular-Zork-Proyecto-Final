<div id="sidebar-left">
	<?php require_once('menuSideBarIzq.php'); ?>
    <div id="div-results"></div>
</div>