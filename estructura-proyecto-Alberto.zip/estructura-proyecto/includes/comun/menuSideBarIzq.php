<div id="menuIzq">
		<div id="botonSideBarIzq" class="col-lg-12">
    <script type="text/javascript" src="zork/javascript/sideBar.js"></script>

			<!-- Para los enlaces de la barra de menu -->
			<a class="button" id="btn1">Noticias</a>
			<a class="button" id="btn2">Eventos</a>
			<a class="button" id="btn3">Cofre</a>
		</div>
</div>