    <div id="contenido">
            <ul id= "principal">
                <h1>Dudas más frecuentes</h1>
                <li class = "prin"><a href ='objetivo.php' class = "prin">Objetivo del juego</a></li>
                <li class = "prin"><a href ='ayudaCreacion.php' class = "prin">Creación</a></li>
                <li class = "prin"><a href ='ayudaRanking.php' class = "prin">Ranking</a></li>
                <li class = "prin"><a href ='ayudaCompras.php' class = "prin">Compras</a></li>
            </ul>
    </div>