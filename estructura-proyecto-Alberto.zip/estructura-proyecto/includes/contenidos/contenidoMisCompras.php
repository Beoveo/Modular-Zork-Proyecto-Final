<div id="contenido">
	<div class="misObjetos">
<!--	<form id="form1" runat="server">  -->
		<div class="Table">
        <div class="Title">
            <h2>Tabla de Objetos</h2>
        </div>
        <div class="Heading">
            <div class="Cell"> <p>Nombre</p> </div>
            <div class="Cell">  <p>Tipo</p> </div>
            <div class="Cell">  <p>Descripci�n</p>  </div>
			<div class="Cell"> <p>Imagen</p>  </div>
        </div>
       <div class="Row">
            <div class="Cell"> <p>Desierto</p> </div>		<!--Nombre -->
            <div class="Cell"> <p>mapa</p> </div>					<!--tipo -->
            <div class="Cell"> <p>Tiene monstruos especiales...Es complicado sobrevivir</p> </div>					<!-- Descripcion -->
			<div class="Cell"> <p><img id="imCompras" src="img/desierto.jpg"/></p> </div>					<!-- Imagen -->
        </div>
        <div class="Row">
            <div class="Cell"> <p>Troll</p> </div>		<!--Nombre -->
            <div class="Cell"> <p>monstruo</p> </div>					<!--tipo -->
            <div class="Cell"> <p>Asusta mucho ,pero le dan miedo los bichos</p> </div>					<!-- Descripcion -->
			<div class="Cell"> <p><img id="imCompras" src="img/troll.jpg"/></p> </div>					<!-- Imagen -->
        </div>
		<div class="Row">
            <div class="Cell"> <p>Hacha</p> </div>		<!--Nombre -->
            <div class="Cell"> <p>arma</p> </div>					<!--tipo -->
            <div class="Cell"> <p>Hace un poquito de da�o</p> </div>					<!-- Descripcion -->
			<div class="Cell"> <p><img id="imCompras" src="img/hacha.jpg"/></p> </div>					<!-- Imagen -->
        </div>
		<div class="Row">
            <div class="Cell"> <p>Bomba</p> </div>		<!--Nombre -->
            <div class="Cell"> <p>arma</p> </div>					<!--tipo -->
            <div class="Cell"> <p>Elimina enemigos fuertes</p> </div>					<!-- Descripcion -->
	    <div class="Cell"> <p><img id="imCompras" src="img/objeto.png"/></p> </div>					<!-- Imagen -->
        </div>
    </div>
 <!--   </form> -->
	</div>
</div>
