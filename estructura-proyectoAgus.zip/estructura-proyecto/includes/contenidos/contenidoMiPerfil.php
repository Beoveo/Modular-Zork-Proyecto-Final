<div id="contenido">
    <div id="imagenFromulario">
     <img id ="imgPerf" src="img/agu.png" alt=""/>
     <form name="uploadimage" type="POST" enctype="multipar/fromdata">
        <input type="file" name="imagen"/>
        <input type="submit" name="uploadimage" value="Subir imagen"/> 
     </form>
    </div>
    <div id=infoPerfil>
        <h3 id="agustin">Nombre de usuario:</h3>
        <p>Agustin Jofre Millet</p>
        <a href='cambiarNombre.php'type='button' >Cambiar Nombre</a>
        <h3 id="correo">Correo Electronico:</h3>
        <p>agustin@ucm.es</p>
        <a href='cambiarCorreo.php'type='button' >Cambiar Correo</a>
        <h3 id="agustin">Contraseña:</h3>
        <p> *********</p>
        <a href='cambiarContraseña.php'type='button' >Cambiar Contraseña</a>
        </div>
	</div>