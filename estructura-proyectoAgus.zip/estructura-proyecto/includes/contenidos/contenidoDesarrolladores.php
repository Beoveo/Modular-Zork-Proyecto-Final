<div id="contenido">
			<h3 id="lidia" >Lidia Barja Diez
				<img id ="imgMiembro1" src="img/lid.png" alt=""/>
			</h3>

			<p>
				<em>Aptitudes transcendentes:</em>
				Brazo derecho del equipo, representante del Grado de Ingenieria Informatica.. su versatilidad nos dara el potencial que nos hace falta.
			</p>
			<p> <em> Contacto:</em> <a href="mailto:lbarja@ucm.es">lbarja@ucm.es</a></p>
		
			<h3 id="miguel">Miguel Pérez de la Rubia
				<img id ="imgMiembro2" src="img/mig.png" alt=""/> 
			</h3>

			<p>
				<em>Aptitudes transcendentes:</em>
				Miembro mas perspicaz del grupo, se mesa la barba con destreza (El que pone la pasta..)
			</p>
			<p> <em> Contacto:</em> <a href="mailto:miguep06@ucm">miguep06@ucm</a></p>

			<h3 id="agustin">Agustin Jofre Millet  
				<img id ="imgMiembro3" src="img/agu.png" alt=""/>
			</h3>

			<p>
				<em>Aptitudes transcendentes:</em>
				Sabio y diseñador del equipo.. sabe todo lo necesario para crear estilo.. pese a ser zurdo.
			</p>
			<p> <em> Contacto:</em> <a href="mailto:ajofre@ucm.es">ajofre@ucm.es</a></p>

			<h3 id="alberto">Alberto Caballero Gámez
				<img id ="imgMiembro4" src="img/alb.png" alt=""/>
			</h3>
			<p>
				<em>Aptitudes transcendentes:</em> 
				Estudiante en Igenieria de Computadores, en la Universidad Complutense de Madrid, todavia no graduado pero casi.. o eso cree.
			</p>
			<p> <em> Contacto:</em> <a href="mailto:alberc01@ucm.es">alberc01@ucm.es</a>  </p>

			<h3 id="beatriz">Beatriz Villegas Sánchez 
				<img id ="imgMiembro5" src="img/bea.png" alt=""/>
			</h3>
			<p>
				<em>Aptitudes transcendentes:</em> 
				Perfeccionista y razonable siempre que tenga la razon, aunque sea un poco zurda.

			</p>
			<p> <em> Contacto:</em>  <a href="mailto:beaville@ucm.es">beaville@ucm.es</a></p>

			<h3 id="georgi">Georgi Kirilov Tsirov 
				<img id ="imgMiembro6" src="img/geo.png" alt=""/>
			</h3>
			<p>
				<em>Aptitudes transcendentes:</em>
				Electronico del  equipo, hombre de pocas palabras, pero todo lo que dice tiene sentido... si sabes Búlgaro.
			</p>
			<p><em> Contacto:</em> <a href="mailto:georgiki@ucm.es">georgiki@ucm.es</a></p>
</div>
