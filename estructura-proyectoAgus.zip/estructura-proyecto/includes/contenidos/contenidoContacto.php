
	<div id="contenido">
	<form action="mailto:contactomz@gmail.com" method="post" enctype="text/plain">
		<p>Nombre: </p> <input type="text" size="15" maxlength="30" value="" name="nombre">
		<p>Dirección de email de contacto: </p>
		<input type="text" size="20" maxlength="30" value="" name="correo" placeholder="micorreo@gmail.es">
			<p>Motivo de la consulta: </p>
				<p><input type="radio" name="transporte2" value="1" checked>Informar de un problema</p>
				<p><input type="radio" name="transporte2" value="2">Sugerencias</p>
				<p><input type="radio" name="transporte2" value="3">Soporte técnico</p>
			<p>Escribe tu consulta:</p>
				<textarea name="comentarios" rows="10" cols="40" placeholder=Escribe aquí tus comentarios></textarea>
				<p><input name="condiciones" type="checkbox" value="aceptadas"> Acepto los terminos y condiciones.</p>
				<p>
					<input type="reset" name="borrar" value="Borrar formulario">
					<input type="submit" value="Enviar">
				</p>
			</form>
	</div>