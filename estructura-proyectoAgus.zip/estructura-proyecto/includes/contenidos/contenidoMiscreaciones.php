<div id="contenido">
	<div class="misCreaciones">
<!--	<form id="form1" runat="server">  -->
        <div class="Table">
            <div class="Title">
                <h2>Tabla de creaciones</h2>
            </div>
            <div class="Heading">
                <div class="Cell"> <p>Nombre</p> </div>
                <div class="Cell">  <p>Num Mazmorras</p> </div>
                <div class="Cell">  <p>Dificultad</p>  </div>
                <div class="Cell"> <p>Valoración</p>  </div>
                <div class="Cell"> <p>Numero de veces jugado</p> </div>
            </div>
           <div class="Row">
                <div class="Cell"> <p>Castillo Chabola</p> </div>		<!--Nombre -->
                <div class="Cell"> <p>5</p> </div>					<!--Num Mazmorras -->
                <div class="Cell"> <p>3</p> </div>					<!-- Dificultad -->
                <div class="Cell"> <p>5</p> </div>					<!-- Valoracion -->
                <div class="Cell"> <p>1</p> </div>					<!--Num veces jugado -->
            </div>
            <div class="Row">
                <div class="Cell"> <p>Cuevas de Zumalacarregui</p> </div>		<!--Nombre -->
                <div class="Cell"> <p>4</p> </div>					<!--Num Mazmorras -->
                <div class="Cell"> <p>4</p> </div>					<!-- Dificultad -->
                <div class="Cell"> <p>3</p> </div>					<!-- Valoracion -->
                <div class="Cell"> <p>2</p> </div>					<!--Num veces jugado -->
            </div>
            <div class="Row">
                <div class="Cell"> <p>Bosque Oscuro</p> </div>		<!--Nombre -->
                <div class="Cell"> <p>6</p> </div>					<!--Num Mazmorras -->
                <div class="Cell"> <p>5</p> </div>					<!-- Dificultad -->
                <div class="Cell"> <p>0</p> </div>					<!-- Valoracion -->
                <div class="Cell"> <p>0</p> </div>					<!--Num veces jugado -->
            </div>
            <div class="Row">
                <div class="Cell"> <p>Pantano de la Muerte</p> </div>		<!--Nombre -->
                <div class="Cell"> <p>6</p> </div>					<!--Num Mazmorras -->
                <div class="Cell"> <p>5</p> </div>					<!-- Dificultad -->
                <div class="Cell"> <p>0</p> </div>					<!-- Valoracion -->
                <div class="Cell"> <p>0</p> </div>					<!--Num veces jugado -->
            </div>
        </div>
 <!--   </form> -->
	</div>
</div>