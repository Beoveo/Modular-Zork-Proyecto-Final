<div id="contenido">
<h1>Modular Zork</h1>
    <div id="subwrapper">
        <div id="zork-area">  	
            <button id="start">Start</button>
        </div>
    </div>
</div>