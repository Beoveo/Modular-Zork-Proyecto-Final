<div id="contenido">
    <h2>Mejores Jugadores</h2>

<!--	<form id="form1" runat="server">  -->
        <div class="Table">
            <div class="Title">
                <h3>Ranking:</h3>
            </div>
            <div class="Heading">
                <div class="Cell"> <p>Posicion</p> </div>
                <div class="Cell"> <p>Usuario</p> </div>
                <div class="Cell"> <p>Puntuacion</p>  </div>
            </div>
            
           <div class="Row">
                <div class="Cell"> <p>1</p> </div>		<!--Nombre -->
                <div class="Cell"> <p>AlbertoMahou</p> </div>					<!--Usuario -->
                <div class="Cell"> <p>30000</p> </div>					<!-- Puntuacion -->

            </div>
            
            <div class="Row">
                <div class="Cell"> <p>2</p> </div>		<!--Nombre -->
                <div class="Cell"> <p>MiguelAñez</p> </div>					<!--Usuario -->
                <div class="Cell"> <p>30000</p> </div>					<!-- Puntuacion -->

            </div>
            
            <div class="Row">
                <div class="Cell"> <p>3</p> </div>		<!--Nombre -->
                <div class="Cell"> <p>BulgarOsoez</p> </div>					<!--Usuario -->
                <div class="Cell"> <p>30000</p> </div>					<!-- Puntuacion -->
            </div>
            
            <div class="Row">
                <div class="Cell"> <p>4</p> </div>		<!--Nombre -->
                <div class="Cell"> <p>BeaMorti</p> </div>					<!--Usuario -->
                <div class="Cell"> <p>30000</p> </div>					<!-- Puntuacion -->

            </div>
            
             <div class="Row">
                <div class="Cell"> <p>5</p> </div>		<!--Nombre -->
                <div class="Cell"> <p>InvernLidia</p> </div>					<!--Num Mazmorras -->
                <div class="Cell"> <p>30000</p> </div>					<!-- Puntuacion -->

            </div>
            
            <div class="Row">
                <div class="Cell"> <p>6</p> </div>		<!--Nombre -->
                <div class="Cell"> <p>AgusTito</p> </div>					<!--Usuario -->
                <div class="Cell"> <p>30000</p> </div>					<!-- Puntuacion -->
            </div>
        </div>
        <p>Se realizara una consulta con el correspondiente archivo.php para ordenar los resultados de mayor a menor puntuacion.</p>
    </div>
