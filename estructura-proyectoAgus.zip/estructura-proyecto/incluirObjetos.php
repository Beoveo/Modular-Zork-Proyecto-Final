

<li class="list-item">
	<div class="list-content">
		<img src="/VM-0007/img/bea.png" alt="" />
	</div>
</li>